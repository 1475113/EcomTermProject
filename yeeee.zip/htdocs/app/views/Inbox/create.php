<html>
<head>
	<title>Send a message</title>
	<link rel="stylesheet" type="text/css" href="/css/bootstrap.css" />
	<script src="/js/boostrap.js"></script>
</head>
<body>
	<div class="container">
		<h1>Send a message</h1>
		<form method="post" action="/Inbox/create" class="form-horizontal" enctype="multipart/form-data">
			<div class="form-group">
			<label for="SenderLoginId">Sender</label>
			<input type="text" class="form-control" name="SenderLoginId" id="SenderLoginId" />
			</div>
			<div class="form-group">
			<label for="ReceiverLoginId">Receiver</label>
			<input type="text" class="form-control" name="ReceiverLoginId" id="ReceiverLoginId" />
			</div>
			<div class="form-group">
			<label for="Message">Message</label>
			<input type="text" class="form-control" name="Message" id="Message" />
			</div>
			<div class="form-group">
			<label for="Date">Date</label>
			<input type="date" class="form-control" name="Date" id="Date" />
			</div>
			<div class="form-group">
			<input type="submit" class="btn btn-default" name="action" value="Publish Car Listing" />
			</div>
		</form>
	</div>
</body>