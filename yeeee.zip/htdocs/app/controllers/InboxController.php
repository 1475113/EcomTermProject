<?php

class InboxController extends Controller
{
	public function index()
	{
		$aInbox = $this->model('Inbox');
		$inbox = $aInbox->get();

		$this->view('Inbox/index',['inbox'=>$inbox]);


/*		$aUsername = $this->model('Login');
		$myUsernames = $aUsername->get();*/
	}

	public function create()
	{
		//$user = $_SESSION['userID'];

		if(isset($_POST['action'])){

			$newInbox = $this->model('CarListing');
			$newInbox->SenderLoginId = $_POST['SenderLoginId'];
			$newInbox->ReceiverLoginId = $_POST['ReceiverLoginId'];
			$newInbox->Message = $_POST['Message'];
			$newInbox->Date = $_POST['Date'];

			$newInbox->insert();
			header('location:/Inbox/create');

		}else{
			$this->view('Inbox/create');
		}
	}
}