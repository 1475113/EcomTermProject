<?php

class CarPartListing
{
	public $_PKName = "CarPartListingId";
	public $carPartMake;
	public $carPartModel;
	public $carPartTrim;
	public $carPartYear;
	public $postDate;
	public $description;
	public $username;
	public $price;
	public $imageId;
	public $regionId;
	public $views;
}