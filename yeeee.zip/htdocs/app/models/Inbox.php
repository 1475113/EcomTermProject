<?php

class Inbox extends Model
{
	public $_PKName = "MessageId";
	public $senderUsername;
	public $recieverUsername;
	public $message;
	public $date;
}