<?php

class carPartListingController extends Controller
{
	public function index()
	{
		$aCarPartListing = $this->model('CarPartListing');
		$myCarPartListings = $aCarPartListing->get();

		$aImagePart = $this->model('Imagepart');

		foreach ($myCarPartListings as $item) {
			if($item != null)
			$item->featurePic = $aImagePart->find($item->ImageId);
		}

		$this->view('CarPartListing/index',['carpartlistings'=>$myCarPartListings]);
		/*$aUsername = $this->model('Login');
		$myUsernames = $aUsername->get();*/
	}

	public function search(){
		$searchTerm = $_GET['search'];
		$aCarPartListing = $this->model('CarPartListing');
		$myCarPartListings = $aCarPartListing-where('carModel','LIKE',"%$searchTerm%")->ORwhere('carMake','LIKE',"%$searchTerm%")->ORwhere('carTrim','LIKE',"%$searchTerm%")->
		ORwhere('carYear','LIKE',"%$searchTerm%")->ORwhere('description','LIKE',"%$searchTerm%")->ORwhere('mileage','LIKE',"$searchTerm")->ORwhere('price','LIKE',"$searchTerm")->get();

		$this->view('CarPartListing/index',['carpartlistings'=>$myCarPartListings]);
	}

	public function regionSearch(){
		$searchTerm = $_GET['search'];
		$aCarPartListing = $this->model('CarPartListing');
		$myCarPartListings = $aCarPartListing->where('');
	}

	public function create()
	{
				if(isset($_POST['action'])){
		//$user = $_SESSION['userID'];
		$newImage = $this->model('Imagepart');
		$target_dir = "uploads/";	//the folder where files will be saved
		$allowedTypes = array("jpg", "png", "jpeg", "gif", "bmp");// Allow certain file formats
		$max_upload_bytes = 5000000;

		foreach($_FILES as $key=>$theFile){
			$uploadOk = 1;
			if(isset($theFile)) {
			//Check if image file is a actual image or fake image
			//this is not a guarantee that malicious code may be passed in disguise
				$check = getimagesize($theFile["tmp_name"]);
			if($check !== false) {
				echo "File is an image - " . $check["mime"] . ".";
				$uploadOk = 1;
			} else {
			echo "File is not an image.";
			$uploadOk = 0;
			}
			$extension = strtolower(pathinfo(basename($theFile["name"]),PATHINFO_EXTENSION));
			//give a name to the file such that it should never collide with an existing file name.
			$target_file_name = uniqid().'.'.$extension;	
			$target_path = $target_dir . $target_file_name;
			//var_dump($target_path);
			$newImage->ImageURL = $target_path;


			//NOTE: that this file path probably should be saved to the database for later retrieval

			//It is very unlikely given the naming scheme that another file of the same name will exist... 
			// Check if file already exists
			/*if (file_exists($target_path)) {
				echo "Sorry, file already exists.";
				$uploadOk = 0;
			}*/

			//You may limit the size of the incoming file... Check file size
			if ($theFile["size"] > $max_upload_bytes) {
				echo "Sorry, your file is too large.";
				$uploadOk = 0;
			}

			// Allow certain file formats
			if(!in_array($extension, $allowedTypes)) {
				echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				$uploadOk = 0;
			}

			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
				echo "Sorry, your file was not uploaded.";
			} else {// if everything is ok, try to upload file - to move it from the temp folder to a permanent folder
				if (move_uploaded_file($theFile["tmp_name"], $target_path)) {
					echo "The file ". basename( $theFile["name"]). " has been 	uploaded as <a href='$target_path'>$target_path</a>.";
					} else {
						echo "Sorry, there was an error uploading your file.";
					}
				}
			}
	}



		date_default_timezone_set("America/New_York");
		$date = date('Y-m-d');

				$newCarListing = $this->model('CarPartListing');
				$newCarListing->description = $_POST['description'];
				$newCarListing->price = $_POST['price'];
				$newCarListing->postDate = $date;
				$newCarListing->loginId = $_SESSION['userID'];
				$newCarListing->regionId = $_POST['RegionId'];
				$newCarListing->views = '0';

				$newCarListing->insert();

						var_dump($newImage);
			}else{
				$regions = $this->model('Region')->get();
				$this->view('CarPartListing/create', ['regions'=>$regions]);

		}
	}


	public function delete($carPartListingId)
	{
		$model = $this->model('carPartListing');
		$listing = $model->where('carPartListingId','=',"$carPartListingId")->get()[0];

		if(LoginCore::isLoggedIn()){
			if($listing->LoginId == $_SESSION['userID']){
				
				$aCarPartListing = $this->model('CarPartListing');
				$aCarPartListing->CarPartListingId = $carPartListingId;
				$aCarPartListing->delete();
				header('location:/CarPartListing/index');
			}

		}else{
			echo '<script> language="javascript">';
			echo 'alert("You must be logged in to use this feature")</script>';
			$this->view('login/login');
		}
	}

	function details($carPartListingId)
	{
		$user = $_SESSION['userID'];
		$carPartListing = $this->model('CarPartListing')->where("CarPartListingId",'=',$carPartListingId)->get()[0];
		$this->view('CarPartListing/details',['carPartListingId'=>$carPartListingId, 'carPartListing'=>$carPartListing]);
	}

	function comment($carPartListingId)
	{
		
	}

	public function edit($carPartListingId)
	{
		if(isset($_POST['action']))
		{
			$listing = $this->model('CarPartListing');
			$session = $listing->where("CarPartListingId",'=', $carPartListingId)->get()[0];
			$session->CarPartListingId = $carPartListingId;
			$session->Description = $_POST['description'];
			$session->Price = $_POST['price'];

			$session->update();

			header('location:/CarPartListing/index');
		}
	}

	public function redirectEdit($carPartListingId)
	{
		if(LoginCore::isLoggedIn()){
			$user = $_SESSION['userID'];
			$carPartListing = $this->model('CarPartListing')->where("CarPartListingId", '=', $carPartListingId)->get()[0];
			$this->view('CarPartListing/edit',['carPartListingId'=>$carPartListingId, 'carPartListing'=>$carPartListing]);
		}else{
			echo '<script> language="javascript">';
			echo 'alert("You must be logged in to use this feature")</script>';
			$this->view('login/login');
		}
	}
}