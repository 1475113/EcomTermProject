<?php

class Image extends Model
{
	public $_PKName = "ImageId";
	public $ListingId;
	public $ImageURL;
}