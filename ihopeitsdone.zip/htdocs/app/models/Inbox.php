<?php

class Inbox extends Model
{
	public $_PKName = "MessageId";
	public $SenderLoginId;
	public $ReceiverLoginId;
	public $Message;
	public $Date;
}