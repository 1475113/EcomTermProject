<?php

class Location
{
	public $locationId;
	public $postal;
	public $address;
}