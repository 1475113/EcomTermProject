<html>
<head>
	<title>Car Part Listings</title>
	<link rel="stylesheet" type="text/css" href="/assets/css/bootstrapz.css" />
	<script src="/js/boostrap.js"></script>
</head>
<body>
	<div class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">
				<div class="navbar-collapse collapse">
			        <ul class="nav navbar-nav ">
			           	<li><a href="/profile/userProfile">Home</a></li>
			            <li><a href="/login/logout">Log Out</a></li>
			            <li><a href="/carListing/index">Car Listings</a></li>
			            <li><a href="/carPartListing/index">Car Part Listings</a></li>
			            <li><a href="/CarListing/wishlist"> Wishlist</a></li>
			        </ul>
			    </div>
			</div>
		</div>
	</div>
	<div class="container">
		<h1>Car Part Listings</h1>
		<form method="get" action="/CarPartListing/search" class="form-inline">
			<div class="form-group">
				<label for="q">Search by Keyword</label>
				<input type="text" class="form-control" name="search" id="search"/>
			</div>
			<div class="form-group">
				<input type="submit" class="btn btn-default" name="action" value='Search'/>
			</div>
		</form>
		<form action="/CarPartListing/regionSearch">
			<label for="region">Search for a Region</label>
			<select name="RegionId">
						<?php 
			foreach($data['regions'] as $region){
				echo "<option value='$region->RegionId'>$region->RegionName</option>";
			}
			?>
			</select>
		</form>
		<form action="/CarPartListing/create">
			<input type="submit" name="action" value='Create'/>
		</form>
		</form><br>
		<br>

		<table class="table table-striped">
			<tr>
				<th>		</th>
				<th>Post Date</th>
				<th>Description</th>
				<th>Seller Username</th>
				<th>Price</th>
				<th>Region</th>
				<th>		</th>
				<th>		</th>
			</tr>
			<?php
			foreach ($data['carpartlistings'] as $carpartlisting) {
				//$user = $_SESSION['userID'];
				$model = $this->model('Login');
				$login = $model->where('LoginId','=', "$carpartlisting->LoginId")->get()[0];
				$username = $login->Username;

				$regionModel = $this->model('Region');
				$region = $regionModel->where('RegionId', '=', "$carpartlisting->RegionId")->get()[0];
				$regionName = $region->RegionName;

				echo "<tr><td><a class='btn btn-default' href='/carPartListing/details/$carpartlisting->CarPartListingId'>Details</a></td>";
				echo "<td>$carpartlisting->PostDate</td>";
				echo "<td>$carpartlisting->Description</td>";
				echo "<td>$username</td>";
				echo "<td>$carpartlisting->Price</td>";
				echo "<td>$regionName</td>";

				if($_SESSION['userID'] == $carpartlisting->LoginId || $_SESSION['userStatus'] == 4)
				{
					echo "<td><a class='btn btn-default' href='/carPartListing/delete/$carpartlisting->CarPartListingId'>Delete</a></td>";
					echo "<td><a class='btn btn-default' href='/carPartListing/redirectEdit/$carpartlisting->CarPartListingId'>Edit</a></td></tr>";
				}else{
					echo "<td></td>";
					echo "<td></td>";
				}
			}
			?>
		</table>
</body>
</html>