<?php

class Wishlist
{
	public $wishlistId;
	public $listingId;
	public $partListingId;
}