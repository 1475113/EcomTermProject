<?php

class Region
{
	public $regionId;
	public $regionName;
}