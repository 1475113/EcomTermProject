<html>
<head>
	<title>Car Part Listings</title>
	<link rel="stylesheet" type="text/css" href="/assets/css/bootstrapz.css" />
	<script src="/js/boostrap.js"></script>
</head>
<body>
	<div class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">
				<div class="navbar-collapse collapse">
			                <ul class="nav navbar-nav ">
			                	<li><a href="/profile/redirectToProfile">Home</a></li>
			                    <li><a href="/login/logout">Log Out</a></li>
			                    <li><a href="/carListing/index">Car Listings</a></li>
			                    <li><a href="/carPartListing/index">Car Part Listings</a></li>
			                </ul>
			    </div>
			</div>
		</div>
	</div>
	<div class="container">
		<h1>Car Part Listings - Create</h1>
		<form method="post" action="/CarPartListing/create" class="form-horizontal">
			<div class="form-group">
			<label for="description">Description</label>
			<input type="text" class="form-control" name="description" id="description" />
			</div>
			<div class="form-group">
			<label for="price">Price</label>
			<input type="text" class="form-control" name="price" id="price" />
			</div>
			<div class="form-group">
			<label for="postDate">Date</label>
			<input type="Date" class="form-control" name="postDate" id="postDate" />
			</div>
			<div class="form-group">
			<form>
			<label for="region">Region</label>
			<select name="RegionId">
			<?php 
			foreach($data['regions'] as $region){
				echo "<option value='$region->RegionId'>$region->RegionName</option>";
			}
			?>
			</select>
			</div>
			<div class="form-group">
			<input type="submit" class="btn btn-default" name="action" value="Publish Car Part Listing" />
			</div>
		</form>
	</div>
</body>