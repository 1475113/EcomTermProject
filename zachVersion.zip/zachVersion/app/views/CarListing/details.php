<!DOCTYPE html>
<html>
<head>
	<title>Car Listings</title>
	<link rel="stylesheet" type="text/css" href="/assets/css/bootstrap.css" />
	<script src="/js/boostrap.js"></script>
</head>
<body>
	<div class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">
				<div class="navbar-collapse collapse">
			                <ul class="nav navbar-nav ">
			                	<li><a href="/profile/redirectToProfile">Home</a></li>
			                    <li><a href="/login/logout">Log Out</a></li>
			                    <li><a href="/carListing/index">Car Listings</a></li>
			                    <li><a href="/carPartListing/index">Car Part Listings</a></li>
			                    <!--<a href="#" class="btn btn-primary">Search</a>-->
			                </ul>
			    </div>
			</div>
		</div>
	</div>

	<div class="container">
		<h1>Car Listings - Details for <?php echo $data['carListing']->CarMake; ?> <?php echo $data['carListing']->CarModel; ?> <?php echo $data['carListing']->CarTrim; ?> <?php echo $data['carListing']->CarYear; ?> </h1>
		<form class="form-horizontal">

			<?php
			$model = $this->model('Login');
			$loginId = $data['carListing']->LoginId;
			$listCreator = $model->where('LoginId','=', "$loginId")->get()[0];
			$username = $listCreator->Username;

			$model = $this->model('Region');
			$id = $data['carListing']->RegionId;
			$listingRegion = $model->where('RegionId','=',"$id")->get()[0];
			$region = $listingRegion->RegionName;
			?>

			<div class="form-group">
			<label>Seller Username</label>
			<input type="text" class="form-control" name="loginId" id="loginId" readonly="readonly" placeholder="<?php echo $username; ?>" />
			</div>
			<div class="form-group">
			<label>Region</label>
			<input type="text" class="form-control" name="regionId" id="regionId" readonly="readonly" placeholder="<?php echo $region; ?>" />
			</div>
			<div class="form-group">
			<label>Car Make</label>
			<input type="text" class="form-control" name="carMake" id="carMake" readonly="readonly" placeholder="<?php echo $data['carListing']->CarMake; ?>" />
			</div>
			<div class="form-group">
			<label>Car Model</label>
			<input type="text" class="form-control" name="carModel" id="carModel" readonly="readonly" placeholder="<?php echo $data['carListing']->CarModel; ?>" />
			</div>
			<div class="form-group">
			<label>Car Trim</label>
			<input type="text" class="form-control" name="carTrim" id="carTrim" readonly="readonly" placeholder="<?php echo $data['carListing']->CarTrim; ?>" />
			</div>
			<div class="form-group">
			<label>Car Year</label>
			<input type="text" class="form-control" name="carYear" id="carYear" readonly="readonly" placeholder="<?php echo $data['carListing']->CarYear; ?>"/>
			</div>
			<div class="form-group">
			<label>Description</label>
			<input type="text" class="form-control" name="description" id="description" readonly="readonly" placeholder="<?php echo $data['carListing']->Description; ?>"/>
			</div>
			<div class="form-group">
			<label>Mileage</label>
			<input type="text" class="form-control" name="mileage" id="mileage" readonly="readonly" placeholder="<?php echo $data['carListing']->Mileage; ?>"/>
			</div>
			<div class="form-group">
			<label>Price</label>
			<input type="text" class="form-control" name="price" id="price" readonly="readonly" placeholder="<?php echo $data['carListing']->Price; ?>"/>
			</div>
			<div class="form-group">
			<label>Post Date</label>
			<input type="text" class="form-control" name="price" id="price" readonly="readonly" placeholder="<?php echo $data['carListing']->PostDate; ?>"/>
			</div>
		</form>
		<form method="post" action="/carlisting/comment" class="form-horizontal">
			<div class="form-group">
				<b><font size="4">Add a Comment</font></b>
				<textarea type="text" class="form control" name="comment" id="comment" placeholder="Comment..." rows="6" cols="164"></textarea>
			<div class="form-group">
		</form>
	</div>
</body>