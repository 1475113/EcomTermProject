<?php

class CarPartListing extends Model
{
	public $_PKName = "CarPartListingId";
	public $postDate;
	public $description;
	public $loginId;
	public $price;
	public $imageId;
	public $regionId;
	public $views;
}