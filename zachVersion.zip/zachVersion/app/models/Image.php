<?php

class Image
{
	public $_PKName = "ImageId";
	public $imageUrl;
}