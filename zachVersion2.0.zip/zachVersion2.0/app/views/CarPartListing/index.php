<html>
<head>
	<title>Car Part Listings</title>
	<link rel="stylesheet" type="text/css" href="/assets/css/bootstrapz.css" />
	<script src="/js/boostrap.js"></script>
</head>
<body>
	<div class="container">
		<h1>Car Part Listings</h1>
		<div class="navbar-collapse collapse">
            <ul class="nav navbar-nav ">
                <li><a href="/profile/userProfile">Home</a></li>
                <li><a href="/carListing/index">Car Listings</a></li>
                <li><a href="/carPartListing/index">Car Part Listings</a></li>
            </ul>
        </div>
		<form method="get" action="/CarListing/search" class="form-inline">
			<div class="form-group">
				<label for="q">Search by Keyword</label>
				<input type="text" class="form-control" name="search" id="search"/>
			</div>
			<div class="form-group">
				<input type="submit" class="btn btn-default" name="action" value='Search'/>
			</div>
		</form>
			<form action="/CarPartListing/create">
				<input type="submit" name="action" value='Create'/>
			</form>
		</form><br>
		<br>

		<table class="table table-striped">
			<tr>
				<th>		</th>
				<th>Post Date</th>
				<th>Description</th>
				<th>Seller Username</th>
				<th>Price</th>
				<th>		</th>
				<th>		</th>
			</tr>
			<?php
			foreach ($data['carpartlistings'] as $carpartlisting) {
				//$user = $_SESSION['userID'];
				echo "<tr><td><a class='btn btn-default' href='/carPartListing/details/$carpartlisting->CarPartListingId'>Details</a></td>";
				echo "<td>$carpartlisting->PostDate</td>";
				echo "<td>$carpartlisting->Description</td>";
				echo "<td>$carpartlisting->LoginId</td>";
				echo "<td>$carpartlisting->Price</td>";
				echo "<td><a class='btn btn-default' href='/carPartListing/delete/$carpartlisting->CarPartListingId'>Delete</a></td>";
				echo "<td><a class='btn btn-default' href='/carPartListing/redirectEdit/$carpartlisting->CarPartListingId'>Edit</a></td></tr>";
			}
			?>
		</table>
</body>
</html>