<!DOCTYPE html>
<html>
<head>
	<title>Car Listings</title>
	<link rel="stylesheet" type="text/css" href="/assets/css/bootstrap.css" />
	<script src="/js/boostrap.js"></script>
</head>
<body>

	<div class="container">
		<h1>Car Part Listings - Details</h1>
		<form method="post" action="/carPartListing/edit/<?php echo $data['carPartListingId']; ?>" class="form-horizontal">
			<div class="form-group">
			<label>Seller Username</label>
			<input type="text" class="form-control" name="loginId" id="loginId" readonly="readonly" placeholder="<?php echo $data['carPartListing']->LoginId; ?>" />
			</div>
			<div class="form-group">
			<label>Region</label>
			<input type="text" class="form-control" name="regionId" id="regionId" readonly="readonly" placeholder="<?php echo $data['carPartListing']->RegionId; ?>" />
			</div>
			<div class="form-group">
			<label>Description</label>
			<input type="text" class="form-control" name="description" id="description" readonly="readonly" placeholder="<?php echo $data['carPartListing']->Description; ?>"/>
			</div>
			<div class="form-group">
			<label>Price</label>
			<input type="text" class="form-control" name="price" id="price" readonly="readonly" placeholder="<?php echo $data['carPartListing']->Price; ?>"/>
			</div>
			<div class="form-group">
			<label>Post Date</label>
			<input type="text" class="form-control" name="price" id="price" readonly="readonly" placeholder="<?php echo $data['carPartListing']->PostDate; ?>"/>
			</div>
			<div class="form-group">
			<br/>
		</form>
	</div>
</body>