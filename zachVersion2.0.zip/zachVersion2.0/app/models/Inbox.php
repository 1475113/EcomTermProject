<?php

class Inbox
{
	public $_PKName = "MessageId";
	public $senderUsername;
	public $recieverUsername;
	public $message;
	public $date;
}