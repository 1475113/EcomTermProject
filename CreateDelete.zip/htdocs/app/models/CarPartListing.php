<?php

class CarPartListing
{
	public $carPartListingId;
	public $carPartMake;
	public $carPartModel;
	public $carPartTrim;
	public $carPartYear;
	public $postDate;
	public $description;
	public $username;
	public $price;
	public $imageId;
	public $regionId;
	public $views;
}