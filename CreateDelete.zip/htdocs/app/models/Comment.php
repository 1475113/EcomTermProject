<?php

class Comment
{
	public $id;
	public $username;
	public $comment;
	public $listingId;
	public $partListingId;
}