<?php

class BusinessProfile
{
	public $bProfileId;
	public $username;
	public $businessName;
	public $locationId;
	public $rating;
	public $ratingCounter;
	public $phone;
	public $email;
}