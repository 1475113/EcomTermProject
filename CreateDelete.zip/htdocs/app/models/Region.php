<?php

class Region extends Model
{
	public $regionId;
	public $regionName;
}