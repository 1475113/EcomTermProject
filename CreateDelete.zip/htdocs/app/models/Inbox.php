<?php

class Inbox
{
	public $messageId;
	public $senderUsername;
	public $recieverUsername;
	public $message;
	public $date;
}