<?php

class Image
{
	public $imageId;
	public $imageUrl;
}