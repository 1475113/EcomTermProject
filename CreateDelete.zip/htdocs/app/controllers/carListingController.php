<?php

class carListingController extends Controller
{
	public function index()
	{
		$aCarListing = $this->model('CarListing');
		$myCarListings = $aCarListing->get();

		$this->view('CarListing/index',['carlistings'=>$myCarListings]);

/*		$aUsername = $this->model('Login');
		$myUsernames = $aUsername->get();*/
	}

	public function search(){
		$searchTerm = $_GET['search'];
		$aCarListing = $this->model('CarListing');
		//var_dump($aCarListing);
		$myCarListings = $aCarListing->where('carMake','LIKE',"%$searchTerm%")->get();
		$myCarListings = $aCarListing->where('carModel','LIKE',"%$searchTerm%")->get();
		var_dump($myCarListings);
		$this->view('CarListing/index',['carlistings'=>$myCarListings]);
	}


	public function create()
	{
		//$user = $_SESSION['userID'];


		if(isset($_POST['action'])){
			$newCarListing = $this->model('CarListing');
			$newCarListing->carMake = $_POST['carMake'];
			$newCarListing->carModel = $_POST['carModel'];
			$newCarListing->carTrim = $_POST['carTrim'];
			$newCarListing->carYear = $_POST['carYear'];
			$newCarListing->description = $_POST['description'];
			$newCarListing->mileage = $_POST['mileage'];
			$newCarListing->price = $_POST['price'];
			$newCarListing->postDate = $_POST['postDate'];
			$newCarListing->loginId = '1';
			$newCarListing->regionId = $_POST['RegionId'];

			$newCarListing->insert();
			header('location:/CarListing/index');

		}else{
			$regions = $this->model('Region')->get();
			$this->view('CarListing/create', ['regions'=>$regions]);
		}
	}
	
	function delete($carListingId)
	{
			$aCarListing = $this->model('CarListing');
			$aCarListing->CarListingId = $carListingId;
			//var_dump($aCarListing);
			$aCarListing->delete();
			header("location:/CarListing/index");
	}
}