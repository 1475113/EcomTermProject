<?php 

class ContactController extends Controller
{
	public function index() 
	{
		echo 'contact index';
	}
}