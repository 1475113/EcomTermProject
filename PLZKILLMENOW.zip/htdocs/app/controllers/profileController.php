<?php 

class ProfileController extends Controller
{
	public function userProfile($id)
	{
		if(LoginCore::isLoggedIn())
		{
			$profile = $this->model('Profile');

			$sessionProfile = $profile->where('LoginId','=', "$id")->get();
			$this->view('profile/profile',['profiles'=>$sessionProfile]);
		}else
		{
			$this->view('login/login');
		}
	}

	public function bProfile($id)
	{
		if($id == null)
			$id = $_SESSION['userID'];

		if(LoginCore::isLoggedIn())
		{
			$profile = $this->model('BusinessProfile');

			$sessionProfile = $profile->where('LoginId','=', "$id")->get();
			$this->view('profile/businessProfile',['profiles'=>$sessionProfile,'businessProfileId'=>$id]);
		}else{
			$this->view('login/login');
		}	
	}

	public function redirectUpdate()
	{
		$user = $_SESSION['userID'];
		$profile = $this->model('Login');

		$sessionProfile = $profile->where('LoginId','=', "$user")->get()[0];

		if(LoginCore::isLoggedIn())
	 	{
	 		if($_SESSION['userID'] == $sessionProfile->LoginId){
		 		if($sessionProfile->Status == 2)
		 		{
		 			$profile2 = $this->model('BusinessProfile');

					$sessionProfile2 = $profile2->where('LoginId','=', "$user")->get()[0];

		 			$this->view('profile/bUpdate',['profile'=>$sessionProfile2]);
		 		}
		 		else if ($sessionProfile->Status == 1) 
		 		{
		 			$profile1 = $this->model('Profile');

					$sessionProfile1 = $profile1->where('LoginId','=', "$user")->get()[0];

		 			$this->view('profile/update',['profile'=>$sessionProfile1]);

		 		}
		 	}
		 	else{
		 		echo '<script> language="javascript">';
		 		echo 'alert("Invalid user is logged in")</script>';
		 		$this->view('login/login');
		 	}
	 	}else
	 	$this->view('login/login');
	}

	public function update()
	{
		if(isset($_POST['action']))
		{
			$user = $_SESSION['userID'];
			$profile = $this->model('Profile');
			$session = $profile->where('LoginId','=',"$user")->get()[0];
			$session->Email = $_POST['Email'];
			$session->Phone = $_POST['Phone'];

			$session->update();

			header('location:/profile/userProfile');
		}
	}

	public function bUpdate()
	{
		if(isset($_POST['action']))
		{
			$user = $_SESSION['userID'];
			$profile = $this->model('BusinessProfile');
			$session = $profile->where('LoginId','=',"$user")->get()[0];
			$session->Email = $_POST['Email'];
			$session->Phone = $_POST['Phone'];
			$session->Address = $_POST['Address'];
			$session->Postal = $_POST['Postal'];

			$session->update();

			header('location:/profile/bProfile');
		}
	}

	public function deleteLogin($id)
	{
		$user = $id;
		$currLog = $this->model('Login');
		$session = $currLog->where('LoginId','=',"$user")->get()[0];
		$status = $session->Status;

		$currLog->LoginId = $id;
		$currLog->delete();
		$this->view('home/index');
	}

	public function confirmDelete()
	{
		$this->view('profile/confirmDelete');
	}

	public function redirectToProfile()
	{
		$user = $this->model('Login');
		$session = $_SESSION['username'];
	 	$status = $user->where('username','=',"$session")->get();

	 	if(LoginCore::isLoggedIn())
	 	{
	 		if($status[0]->Status == 2)
	 		{
	 			header('location:/profile/bProfile');
	 		}
	 		else if ($status[0]->Status == 1) 
	 		{
	 			header('location:/profile/userProfile');
	 		}
	 		else if($status[0]->Status == 4)
	 		{
	 			header('location:/admin/adminMain');
	 		}
	 	}
	}

	public function extProfile($id)
	{
		$model = $this->model('Login');
		$login = $model->where('LoginId','=',"$id")->get()[0];
		$status = $login->Status;

		if($status == 2)
	 		{
	 			header("location:/profile/bProfile/$id");
	 		}
	 		else if ($status == 1) 
	 		{
	 			header("location:/profile/userProfile/$id");

	 	}
	}

	public function addRating($businessProfileId)
	{
		if(LoginCore::isLoggedIn()){
			if(isset($_POST['action'])){
				$newRating = $this->model('Rating');
				$newRating->Rating = $_POST['rating'];
				$newRating->LoginId = $_SESSION['userID'];
				$newRating->BusinessProfileId = $businessProfileId;

				$newRating->insert();

				$this->businessProfile($businessProfileId);
			}
		}else{
			echo '<script> language="javascript">';
			echo 'alert("You must be logged in to use this feature")</script>';
			$this->view('login/login');
		}
	}

	public function editRating($ratingId, $businessProfileId)
	{

		if(isset($_POST['action']))
		{
			$rating = $this->model('Rating');
			$session = $rating->where("RatingId", '=', $ratingId)->get()[0];
			$session->RatingId = $ratingId;
			$session->Rating = $_POST['rating'];
			$session->update();

			$this->details($businessProfileId);
		}
	}

	public function redirectEditRating($ratingId)
	{
		if(LoginCore::isLoggedIn()){
			$user = $_SESSION['userID'];
			$rating = $this->model('Rating')->where("RatingId", '=', $ratingId)->get()[0];
			$this->view('profile/editRating',['RatingId'=>$ratingId, 'comment'=>$rating]);
		}else{
			echo '<script> language="javascript">';
			echo 'alert("You must be logged in to use this feature")</script>';
			$this->view('login/login');
		}
	}

	
}
