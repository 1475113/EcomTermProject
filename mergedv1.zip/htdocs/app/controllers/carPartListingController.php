<?php

class carPartListingController extends Controller
{
	public function index()
	{
		$aCarPartListing = $this->model('CarPartListing');
		$myCarPartListings = $aCarPartListing->get();

		$this->view('CarPartListing/index',['carpartlistings'=>$myCarPartListings]);

		/*$aUsername = $this->model('Login');
		$myUsernames = $aUsername->get();*/
	}

	public function search(){
		$searchTerm = $_GET['search'];
		$aCarPartListing = $this->model('CarPartListing');
		$myCarPartListings = $aCarPartListing->where('description','LIKE',"%$searchTerm%")->ORwhere('price','LIKE',"$searchTerm")->get();
		$this->view('CarPartListing/index',['carpartlistings'=>$myCarPartListings]);
	}

	public function regionSearch(){
		$searchTerm = $_GET['search'];
		$aCarPartListing = $this->model('CarPartListing');
		$myCarPartListings = $aCarPartListing->where('');
	}

	public function create()
	{
		if(LoginCore::isLoggedIn()){
			if(isset($_POST['action'])){
				$newCarPartListing = $this->model('CarPartListing');
				$newCarPartListing->postDate = $_POST['postDate'];
				$newCarPartListing->description = $_POST['description'];
				$newCarPartListing->price = $_POST['price'];
				$newCarPartListing->loginId = $_SESSION['userID'];
				$newCarPartListing->regionId = $_POST['RegionId'];

				$newCarPartListing->insert();
				header('location:/CarPartListing/index');

			}else{
				$regions = $this->model('Region')->get();
				$this->view('CarPartListing/create', ['regions'=>$regions]);
			}
		}else{
			echo '<script> language="javascript">';
			echo 'alert("You must be logged in to use this feature")</script>';
			$this->view('login/login');
		}
	}

	public function delete($carPartListingId)
	{
		$model = $this->model('carPartListing');
		$listing = $model->where('carPartListingId','=',"$carPartListingId")->get()[0];

		if(LoginCore::isLoggedIn()){
			if($listing->LoginId == $_SESSION['userID'] || $_SESSION['userStatus'] == 4){
				
				$aCarPartListing = $this->model('CarPartListing');
				$aCarPartListing->CarPartListingId = $carPartListingId;
				$aCarPartListing->delete();
				header('location:/CarPartListing/index');
			}else{
				echo '<script> language="javascript">';
				echo 'alert("Stop trying to cheat the system")</script>';
				header('location:/login/logout');
			}

		}else{
			echo '<script> language="javascript">';
			echo 'alert("You must be logged in to use this feature")</script>';
			$this->view('login/login');
		}
	}

	function details($carPartListingId)
	{
		$user = $_SESSION['userID'];
		$carPartListing = $this->model('CarPartListing')->where("CarPartListingId",'=',$carPartListingId)->get()[0];
		$this->view('CarPartListing/details',['carPartListingId'=>$carPartListingId, 'carPartListing'=>$carPartListing]);
	}

	function comment($carPartListingId)
	{
		
	}

	public function edit($carPartListingId)
	{
		$model = $this->model('carPartListing');
		$listing = $model->where('carPartListingId','=',"$carPartListingId")->get()[0];

		if($listing->LoginId == $_SESSION['userID'] || $_SESSION['userStatus'] == 4){
			if(isset($_POST['action']))
			{
				$listing = $this->model('CarPartListing');
				$session = $listing->where("CarPartListingId",'=', $carPartListingId)->get()[0];
				$session->CarPartListingId = $carPartListingId;
				$session->Description = $_POST['description'];
				$session->Price = $_POST['price'];

				$session->update();

				header('location:/CarPartListing/index');
			}else{
				echo '<script> language="javascript">';
				echo 'alert("Stop trying to cheat the system")</script>';
				header('location:/login/logout');
			}
		}
	}

	public function redirectEdit($carPartListingId)
	{
		if(LoginCore::isLoggedIn()){
			$user = $_SESSION['userID'];
			$carPartListing = $this->model('CarPartListing')->where("CarPartListingId", '=', $carPartListingId)->get()[0];
			$this->view('CarPartListing/edit',['carPartListingId'=>$carPartListingId, 'carPartListing'=>$carPartListing]);
		}else{
			echo '<script> language="javascript">';
			echo 'alert("You must be logged in to use this feature")</script>';
			$this->view('login/login');
		}
	}
}
