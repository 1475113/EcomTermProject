<?php
class HomeController extends Controller
{
	/**
	 * The default Controller method
	 *
	 * @return void
	 */
	 public function index()
	 {
		 $this->view('home/index');
	 }
	 public function test($name = '', $otherName = '')
	 {
		 echo $name . ' ' . $otherName;
	 }
}