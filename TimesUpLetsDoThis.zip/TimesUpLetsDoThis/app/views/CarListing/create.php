<html>
<head>
	<title>Car Listings</title>
	<link rel="stylesheet" type="text/css" href="/assets/css/bootstrapz.css" />
	<script src="/js/boostrap.js"></script>
</head>
<body>
	<div class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">
				<div class="navbar-collapse collapse">
			                <ul class="nav navbar-nav ">
			                	<li><a href="/profile/redirectToProfile">Home</a></li>
			                    <li><a href="/login/logout">Log Out</a></li>
			                    <li><a href="/carListing/index">Car Listings</a></li>
			                    <li><a href="/carPartListing/index">Car Part Listings</a></li>
			                </ul>
			    </div>
			</div>
		</div>
	</div>
	<div class="container">
		<h1>Car Listings - Create</h1>
		<form method="post" action="/CarListing/create" class="form-horizontal" enctype="multipart/form-data">
			<div class="form-group">
			<label for="carMake">Car Make</label>
			<input type="text" class="form-control" name="carMake" id="carMake" maxlength="15" />
			</div>
			<div class="form-group">
			<label for="carModel">Car Model</label>
			<input type="text" class="form-control" name="carModel" id="carModel" maxlength="15"/>
			</div>
			<div class="form-group">
			<label for="carTrim">Car Trim</label>
			<input type="text" class="form-control" name="carTrim" id="carTrim" maxlength="15"/>
			</div>
			<div class="form-group">
			<label for="carYear">Car Year</label>
			<input type="text" class="form-control" name="carYear" id="carYear" maxlength="4"/>
			</div>
			<div class="form-group">
			<label for="description">Description</label>
			<input type="text" class="form-control" name="description" id="description" />
			</div>
			<div class="form-group">
			<label for="mileage">Mileage</label>
			<input type="text" class="form-control" name="mileage" id="mileage" maxlength="6"/>
			</div>
			<div class="form-group">
			<label for="price">Price</label>
			<input type="text" class="form-control" name="price" id="price" />
			</div>
			<div class="form-group">
			<label for="region">Region</label>
			<select name="RegionId">
			<?php 
			foreach($data['regions'] as $region){
				echo "<option value='$region->RegionId'>$region->RegionName</option>";
			}
			?>
			</select>
			</div>
			<div class="form-group">
			<label for="region">Image Upload</label>
			<input type="file" name="fileToUpload" id="fileToUpload">
			</div>
			<div class="form-group">
			<input type="submit" class="btn btn-default" name="action" value="Publish Car Listing" />
			</div>
		</form>
	</div>
</body>