<html>
<head>
	<title> Car Listings </title>
	<link rel="stylesheet" type="text/css" href="/assets/css/bootstrapz.css" />
	<script src="/js/boostrap.js"></script>
</head>
<body>
	<div class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">
				<div class="navbar-collapse collapse">
			                <ul class="nav navbar-nav ">
			                	<li><a href="/profile/redirectToProfile">Home</a></li>
			                    <li><a href="/login/logout">Log Out</a></li>
			                    <li><a href="/carListing/index">Car Listings</a></li>
			                    <li><a href="/carPartListing/index">Car Part Listings</a></li>
			                    <!--<a href="#" class="btn btn-primary">Search</a>-->
			                </ul>
			    </div>
			</div>
		</div>
	</div>
	<div class="container">
		<h1>Wishlist</h1>
		<table class="table table-striped">
			<tr>
				<th>Car Make</th>
				<th>Car Model</th>
				<th>Car Trim</th>
				<th>Car Year</th>
			</tr>
			<?php
			foreach ($data['Wishlist'] as $carlisting) {
				echo "<tr><td>$carlisting->CarMake</td>";
				echo "<td>$carlisting->CarModel</td>";
				echo "<td>$carlisting->CarTrim</td>";
				echo "<td>$carlisting->CarYear</td>";
				?>
				<img src="/<?php echo $carlisting->featurePic->ImageURL; ?>" name="ImageDisplay">
				<?php
				echo "<td><a class='btn btn-default' href='/carListing/delete/$carlisting->CarListingId'>Delete</a></td></tr>";
			}
			?>
		</table>
</body>
</html>