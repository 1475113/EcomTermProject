<?php

class carListingController extends Controller
{
	public function index()
	{
		$aCarListing = $this->model('CarListing');
		$myCarListings = $aCarListing->get();

		$aImage = $this->model('Image');

		foreach ($myCarListings as $item) {
			if($item != null)
			$item->featurePic = $aImage->find($item->ImageId);
		}

		$this->view('CarListing/index',['carlistings'=>$myCarListings]);

/*		$aUsername = $this->model('Login');
		$myUsernames = $aUsername->get();*/
	}

	public function search(){
		$searchTerm = $_GET['search'];
		$aCarListing = $this->model('CarListing');
		$myCarListings = $aCarListing->where('carModel','LIKE',"%$searchTerm%")->ORwhere('carMake','LIKE',"%$searchTerm%")->ORwhere('carTrim','LIKE',"%$searchTerm%")->
		ORwhere('carYear','LIKE',"%$searchTerm%")->ORwhere('description','LIKE',"%$searchTerm%")->ORwhere('mileage','LIKE',"$searchTerm")->ORwhere('price','LIKE',"$searchTerm")->get();
		$this->view('CarListing/index',['carlistings'=>$myCarListings]);
	}


	public function create()
	{
		//$user = $_SESSION['userID'];

		$newImage = $this->model('Image');
		$target_dir = "uploads/";	//the folder where files will be saved
		$allowedTypes = array("jpg", "png", "jpeg", "gif", "bmp");// Allow certain file formats
		$max_upload_bytes = 5000000;

		foreach($_FILES as $key=>$theFile){
			$uploadOk = 1;
			if(isset($theFile)) {
			//Check if image file is a actual image or fake image
			//this is not a guarantee that malicious code may be passed in disguise
				$check = getimagesize($theFile["tmp_name"]);
			if($check !== false) {
				echo "File is an image - " . $check["mime"] . ".";
				$uploadOk = 1;
			} else {
			echo "File is not an image.";
			$uploadOk = 0;
			}
			$extension = strtolower(pathinfo(basename($theFile["name"]),PATHINFO_EXTENSION));
			//give a name to the file such that it should never collide with an existing file name.
			$target_file_name = uniqid().'.'.$extension;	
			$target_path = $target_dir . $target_file_name;
			//var_dump($target_path);
			$newImage->ImageURL = $target_path;

		var_dump($newImage);
			//NOTE: that this file path probably should be saved to the database for later retrieval

			//It is very unlikely given the naming scheme that another file of the same name will exist... 
			// Check if file already exists
			/*if (file_exists($target_path)) {
				echo "Sorry, file already exists.";
				$uploadOk = 0;
			}*/

			//You may limit the size of the incoming file... Check file size
			if ($theFile["size"] > $max_upload_bytes) {
				echo "Sorry, your file is too large.";
				$uploadOk = 0;
			}

			// Allow certain file formats
			if(!in_array($extension, $allowedTypes)) {
				echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				$uploadOk = 0;
			}

			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
				echo "Sorry, your file was not uploaded.";
			} else {// if everything is ok, try to upload file - to move it from the temp folder to a permanent folder
				if (move_uploaded_file($theFile["tmp_name"], $target_path)) {
					echo "The file ". basename( $theFile["name"]). " has been 	uploaded as <a href='$target_path'>$target_path</a>.";
					} else {
						echo "Sorry, there was an error uploading your file.";
					}
				}
			}
	}
		date_default_timezone_set("America/New_York");
		$date = date('Y-m-d');

		if(LoginCore::isLoggedIn()){
			if(isset($_POST['action'])){
				$newCarListing = $this->model('CarListing');
				$newCarListing->carMake = $_POST['carMake'];
				$newCarListing->carModel = $_POST['carModel'];
				$newCarListing->carTrim = $_POST['carTrim'];
				$newCarListing->carYear = $_POST['carYear'];
				$newCarListing->description = $_POST['description'];
				$newCarListing->mileage = $_POST['mileage'];
				$newCarListing->price = $_POST['price'];
				$newCarListing->postDate = $date;
				$newCarListing->loginId = $_SESSION['userID'];
				$newCarListing->regionId = $_POST['RegionId'];
				$newCarListing->views = '0';

				$newImage->ListingId = $newCarListing::$_connection->lastInsertId();
				$newImage->insert();

				$newCarListing->ImageId = $newImage::$_connection->lastInsertId();
				$newCarListing->CarListingId = $newCarListing::$_connection->lastInsertId();

				$newCarListing->insert();
				header('location:/CarListing/index');

			}else{
				$regions = $this->model('Region')->get();
				$this->view('CarListing/create', ['regions'=>$regions]);
			}
		}else{
			echo '<script> language="javascript">';
			echo 'alert("You must be logged in to use this feature")</script>';
			$this->view('login/login');
		}
	}
	
	function delete($carListingId)
	{
		if(LoginCore::isLoggedIn()){
			$aCarListing = $this->model('CarListing');
			$aCarListing->CarListingId = $carListingId;
			$aCarListing->delete();
			header("location:/CarListing/index");
		}else{
			echo '<script> language="javascript">';
			echo 'alert("You must be logged in to use this feature")</script>';
			$this->view('login/login');
		}
	}

	function details($carListingId)
	{
		$user = $_SESSION['userID'];
		$carListing = $this->model('CarListing')->where("CarListingId",'=',$carListingId)->get()[0];
		$this->view('CarListing/details',['carListingId'=>$carListingId, 'carListing'=>$carListing]);
	}

	public function edit($carListingId)
	{
		if(isset($_POST['action']))
		{
			$listing = $this->model('CarListing');
			$session = $listing->where("CarListingId",'=', $carListingId)->get()[0];
			$session->CarListingId = $carListingId;
			$session->CarMake = $_POST['carMake'];
			$session->CarModel = $_POST['carModel'];
			$session->CarTrim = $_POST['carTrim'];
			$session->CarYear = $_POST['carYear'];
			$session->Description = $_POST['description'];
			$session->Mileage = $_POST['mileage'];
			$session->Price = $_POST['price'];

			$session->update();

			header('location:/carListing/index');
		}
	}

	public function redirectEdit($carListingId)
	{
		if(LoginCore::isLoggedIn()){
			$user = $_SESSION['userID'];
			$carListing = $this->model('CarListing')->where("CarListingId",'=',$carListingId)->get()[0];
			$this->view('CarListing/edit',['carListingId'=>$carListingId, 'carListing'=>$carListing]);
		}else{
			echo '<script> language="javascript">';
			echo 'alert("You must be logged in to use this feature")</script>';
			$this->view('login/login');
		}
	}

	function addWishlist($carListingId)
	{
		$aCarListing = $this->model('CarListing');
		$aWishlist = $this->model('Wishlist');
		$aWishlist->listingId = $carListingId;
		$car = $aCarListing->find($carListingId);
		$aWishlist->CarMake = $car->CarMake;
		$aWishlist->CarModel = $car->CarModel;
		$aWishlist->CarTrim = $car->CarTrim;
		$aWishlist->CarYear = $car->CarYear;

		$aWishlist->insert();
		$this->view('CarListing/wishlist');
	}

	function deleteWishlist($carListingId)
	{
		$aWishlist = $this->model('Wishlist');
		$aWishlist->listingId = $carListingId;

		$aWishlist->delete();
		header("location:/CarListing/wishlist");
	}
}