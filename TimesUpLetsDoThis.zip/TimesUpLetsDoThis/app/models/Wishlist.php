<?php

class Wishlist extends Model
{
	public $_PKName = "WishlistId";
	public $listingId;
	public $CarMake ;
	public $CarModel ;
	public $CarTrim ;
	public $CarYear ;	
}