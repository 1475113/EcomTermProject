<?php

class Comment
{
	public $_PKName = "CommentId";
	public $username;
	public $comment;
	public $listingId;
	public $partListingId;
}