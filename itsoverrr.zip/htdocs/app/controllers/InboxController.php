<?php

class InboxController extends Controller
{
	public function index()
	{
		$aInbox = $this->model('Inbox');
		$inbox = $aInbox->get();

		$this->view('Inbox/index',['inbox'=>$inbox]);

		var_dump($_SESSION);
/*		$aUsername = $this->model('Login');
		$myUsernames = $aUsername->get();*/
	}

	public function create()
	{
		//$user = $_SESSION['userID'];

		if(isset($_POST['action'])){
		try{
			$newInbox = $this->model('Inbox');
			$newInbox->SenderLoginId = $_POST['SenderLoginId'];
			$newInbox->ReceiverLoginId = $_POST['ReceiverLoginId'];
			$newInbox->Message = $_POST['Message'];
			$newInbox->Date = $_POST['Date'];

			$newInbox->insert();
			header('location:/Inbox/index');
		}catch(Exception $e){
			echo $e->getMessage();
			//header('location:/Inbox/create');
		}

		}else{
			$this->view('Inbox/create');
		}
	}
}