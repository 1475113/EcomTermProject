<?php

class carListingController extends Controller
{
	public function index()
	{
		$aCarListing = $this->model('CarListing');
		$myCarListings = $aCarListing->get();

		$aImage = $this->model('Image');

		foreach ($myCarListings as $item) {
			if($item != null)
			$item->featurePic = $aImage->find($item->ImageId);
		}
		
		$this->view('CarListing/index',['carlistings'=>$myCarListings]);


/*		$aUsername = $this->model('Login');
		$myUsernames = $aUsername->get();*/
	}

	public function search(){
		$searchTerm = $_GET['search'];
		$aCarListing = $this->model('CarListing');
		$myCarListings = $aCarListing->where('carMake','LIKE',"%$searchTerm%")->ORwhere('carModel','LIKE',"%$searchTerm%")->ORwhere('carTrim','LIKE',"%$searchTerm%")->ORwhere('carYear','LIKE',"%$searchTerm%")->ORwhere('description','LIKE',"%$searchTerm%")->ORwhere('mileage','LIKE',"%$searchTerm%")->ORwhere('price','LIKE',"$searchTerm")->get();
		$this->view('CarListing/index',['carlistings'=>$myCarListings]);
	}


	public function create()
	{
		//$user = $_SESSION['userID'];


		if(isset($_POST['action'])){

		$newImage = $this->model('Image');
		$target_dir = "uploads/";	//the folder where files will be saved
		$allowedTypes = array("jpg", "png", "jpeg", "gif", "bmp");// Allow certain file formats
		$max_upload_bytes = 5000000;

		foreach($_FILES as $key=>$theFile){
			$uploadOk = 1;
			if(isset($theFile)) {
			//Check if image file is a actual image or fake image
			//this is not a guarantee that malicious code may be passed in disguise
				$check = getimagesize($theFile["tmp_name"]);
			if($check !== false) {
				echo "File is an image - " . $check["mime"] . ".";
				$uploadOk = 1;
			} else {
			echo "File is not an image.";
			$uploadOk = 0;
			}
			$extension = strtolower(pathinfo(basename($theFile["name"]),PATHINFO_EXTENSION));
			//give a name to the file such that it should never collide with an existing file name.
			$target_file_name = uniqid().'.'.$extension;	
			$target_path = $target_dir . $target_file_name;
			//var_dump($target_path);
			$newImage->imageUrl = $target_path;

		//	var_dump($newImage);
			//NOTE: that this file path probably should be saved to the database for later retrieval

			//It is very unlikely given the naming scheme that another file of the same name will exist... 
			// Check if file already exists
			/*if (file_exists($target_path)) {
				echo "Sorry, file already exists.";
				$uploadOk = 0;
			}*/

			//You may limit the size of the incoming file... Check file size
			if ($theFile["size"] > $max_upload_bytes) {
				echo "Sorry, your file is too large.";
				$uploadOk = 0;
			}

			// Allow certain file formats
			if(!in_array($extension, $allowedTypes)) {
				echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				$uploadOk = 0;
			}

			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
				echo "Sorry, your file was not uploaded.";
			} else {// if everything is ok, try to upload file - to move it from the temp folder to a permanent folder
				if (move_uploaded_file($theFile["tmp_name"], $target_path)) {
					echo "The file ". basename( $theFile["name"]). " has been 	uploaded as <a href='$target_path'>$target_path</a>.";
					} else {
						echo "Sorry, there was an error uploading your file.";
					}
				}
			}
	}

			$newCarListing = $this->model('CarListing');
			$newCarListing->carMake = $_POST['carMake'];
			$newCarListing->carModel = $_POST['carModel'];
			$newCarListing->carTrim = $_POST['carTrim'];
			$newCarListing->carYear = $_POST['carYear'];
			$newCarListing->description = $_POST['description'];
			$newCarListing->mileage = $_POST['mileage'];
			$newCarListing->price = $_POST['price'];
			$newCarListing->postDate = $_POST['postDate'];
			$newCarListing->loginId = '1';
			$newCarListing->regionId = $_POST['RegionId'];
			$newCarListing->views = '0';
			

			$newCarListing->insert();
			$newImage->listingId = $newCarListing::$_connection->lastInsertId();
			$newImage->insert();

			$newCarListing->ImageId = $newImage::$_connection->lastInsertId();
			$newCarListing->CarListingId = $newCarListing::$_connection->lastInsertId();
			var_dump($newCarListing);
			$newCarListing->update();
			header('location:/CarListing/index');
		}else{ 
			$regions = $this->model('Region')->get();
			$this->view('CarListing/create', ['regions'=>$regions]);
		}
	}


	function delete($carListingId)
	{
			$aCarListing = $this->model('CarListing');
			$aCarListing->CarListingId = $carListingId;
			//var_dump($aCarListing);
			$aCarListing->delete();
			header("location:/CarListing/index");
	}

	function addWishlist($carListingId)
	{
		$aCarListing = $this->model('CarListing');
		$aWishlist = $this->model('Wishlist');
		$aWishlist->listingId = $carListingId;
		$car = $aCarListing->find($carListingId);
		$aWishlist->CarMake = $car->CarMake;
		$aWishlist->CarModel = $car->CarModel;
		$aWishlist->CarTrim = $car->CarTrim;
		$aWishlist->CarYear = $car->CarYear;

		$aWishlist->insert();
		header("location:/CarListing/wishlist");
	}

	function deleteWishlist($carListingId)
	{
		$aWishlist = $this->model('Wishlist');
		$aWishlist->listingId = $carListingId;

		$aWishlist->delete();
		header("location:/CarListing/wishlist");
	}
}