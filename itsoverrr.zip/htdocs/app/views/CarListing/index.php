<html>
<head>
	<title>Car Listings</title>
	<link rel="stylesheet" type="text/css" href="/css/bootstrap.css" />
	<script src="/js/boostrap.js"></script>
	<script>
function sortTable() {
  var table, rows, switching, i, x, y, shouldSwitch;
  table = document.getElementById("myTable");
  switching = true;
  /*Make a loop that will continue until
  no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.getElementsByTagName("TR");
    /*Loop through all table rows (except the
    first, which contains table headers):*/
    for (i = 1; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
      one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[0];
      y = rows[i + 1].getElementsByTagName("TD")[0];
      //check if the two rows should switch place:
      if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
        //if so, mark as a switch and break the loop:
        shouldSwitch= true;
        break;
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
    }
  }
}
</script>

</head>
<body>
	<div class="container">
		<h1>Car Listings</h1>
		<form method="get" action="/CarListing/search" class="form-inline">
			<div class="form-group">
				<label for="q">Search by Keyword</label>
				<input type="text" class="form-control" name="search" id="search"/>
			</div>
			<div class="form-group">
				<input type="submit" class="btn btn-default" name="action" value='search'/>
			</div>
		</form>
			<form action="/CarListing/create">
				<input type="submit" name="action" value='Create'/>
			</form>
		</form><br>
		<br>
		<p><button onclick="sortTable()">Sort</button></p>
		<table id="myTable" class="table table-striped">
			<tr>
				<th>Car Make</th>
				<th>Car Model</th>
				<th>Car Trim</th>
				<th>Car Year</th>
				<th>Post Date</th>
				<th>Description</th>
				<th>Username</th>
				<th>Mileage</th>
				<th>Price</th>
				<th>Image</th>
			</tr>
			<?php
			foreach ($data['carlistings'] as $carlisting) {
				echo "<tr><td>$carlisting->CarMake</td>";
				echo "<td>$carlisting->CarModel</td>";
				echo "<td>$carlisting->CarTrim</td>";
				echo "<td>$carlisting->CarYear</td>";
				echo "<td>$carlisting->PostDate</td>";
				echo "<td>$carlisting->Description</td>";
				echo "<td>$carlisting->LoginId</td>";
//				echo "<td>$sellerId->username</td>";
				echo "<td>$carlisting->Mileage</td>";
				echo "<td>$carlisting->Price</td>";
				
				?>
				<img src="/<?php echo $carlisting->featurePic->ImageURL; ?>" name="ImageDisplay">
				<?php
				echo "<td><a class='btn btn-default' href='/carListing/addWishlist/$carlisting->CarListingId'>Add to Wishlist</a></td></tr>";
				echo "<td><a class='btn btn-default' href='/carListing/delete/$carlisting->CarListingId'>Delete</a></td></tr>";
			}
			?>
		</table>
</body>
</html>