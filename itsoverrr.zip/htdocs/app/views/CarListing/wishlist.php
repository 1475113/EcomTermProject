<html>
<head>
	<title>Wishlist</title>
	<link rel="stylesheet" type="text/css" href="/css/bootstrap.css" />
	<script src="/js/boostrap.js"></script>
</head>
<body>
	<div class="container">
		<h1>Wishlist</h1>
		<table class="table table-striped">
			<tr>
				<th>Car Make</th>
				<th>Car Model</th>
				<th>Car Trim</th>
				<th>Car Year</th>
			</tr>
			<!--<?php
			/*foreach ($data['wishlist'] as $carlisting) {
				echo "<tr><td>$carlisting->CarMake</td>";
				echo "<td>$carlisting->CarModel</td>";
				echo "<td>$carlisting->CarTrim</td>";
				echo "<td>$carlisting->CarYear</td>";
				?>
				<img src="/<?php echo $carlisting->featurePic->ImageURL; ?>" name="ImageDisplay">
				<?php
				echo "<td><a class='btn btn-default' href='/carListing/delete/$carlisting->CarListingId'>Delete</a></td></tr>";*/
			}
			?>-->
		</table>
</body>
</html>