<html>
<head>
	<title>Inbox</title>
	<link rel="stylesheet" type="text/css" href="/css/bootstrap.css" />
	<script src="/js/boostrap.js"></script>
</head>
<body>
	<div class="container">
		<h1>Messages</h1>
			<form action="/Inbox/create">
				<input type="submit" name="action" value='Send a Message'/>
			</form>
		</form><br>
		<br>

		<table class="table table-striped">
			<tr>
				<th>SenderLoginId</th>
				<th>ReceiverLoginId</th>
				<th>Message</th>
				<th>Date</th>
			</tr>
			<?php
			foreach ($data['inbox'] as $message) {
				echo "<tr><td>$message->SenderLoginId</td>";
				echo "<td>$message->ReceiverLoginId</td>";
				echo "<td>$message->Message</td>";
				echo "<td>$message->Date</td>";
			}
				?>
		</table>
</body>
</html>