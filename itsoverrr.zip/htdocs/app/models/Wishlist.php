<?php

class Wishlist extends Model
{
	public $_PKName = "WishlistId";
	public $listingId;
	public $partListingId;
	public $CarMake;
	public $CarModel;
	public $CarTrim;
	public $CarYear;
}