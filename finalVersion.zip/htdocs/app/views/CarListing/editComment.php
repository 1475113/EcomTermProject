<!DOCTYPE html>
<html>
<head>
	<title>Car Listings</title>
	<link rel="stylesheet" type="text/css" href="/assets/css/bootstrap.css" />
	<script src="/js/boostrap.js"></script>
</head>
<body>
	<div class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">
				<div class="navbar-collapse collapse">
			                <ul class="nav navbar-nav ">
			                	<li><a href="/profile/redirectToProfile">Home</a></li>
			                    <li><a href="/login/logout">Log Out</a></li>
			                    <li><a href="/carListing/index">Car Listings</a></li>
			                    <li><a href="/carPartListing/index">Car Part Listings</a></li>
			                    <!--<a href="#" class="btn btn-primary">Search</a>-->
			                </ul>
			    </div>
			</div>
		</div>
	</div>
	<div class="container">
		<h1>Comment - Update</h1>
		<form method="post" action="/carListing/editComment/<?php echo $data['comment']->CommentId; ?>/<?php echo $data['comment']->ListingId; ?>" class="form-horizontal">
			<div class="form-group">
				<label>Comment</label>
				<textarea type="text" class="form control" name="comment" id="comment" rows="6" cols="164" style="overflow:auto;resize:none"><?php echo $data['comment']->Comment; ?></textarea>
				<br/>

				<input type="submit" class="btn btn-default" name="action" value="Update"/>
			</div>
		</form>
	</div>
</body>

