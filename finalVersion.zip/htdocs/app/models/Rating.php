<?php
class Rating extends Model
{
	public $_PKName = 'RatingId';
	public $LoginId;
	public $Rating;
	public $BusinessProfileId;
	
	public function __construct(){
		parent::__construct();
	}

}