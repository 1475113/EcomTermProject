<?php

class Region extends Model
{
	public $_PKName = "RegionId";
	public $RegionName;
}