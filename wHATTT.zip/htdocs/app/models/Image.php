<?php

class Image extends Model
{
	public $_PKName = "ImageId";
	public $imageUrl;
	public $listingId;
}