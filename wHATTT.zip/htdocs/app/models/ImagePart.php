<?php

class ImagePart extends Model
{
	public $_PKName = "ImageId";
	public $imageUrl;
	public $listingId;
}