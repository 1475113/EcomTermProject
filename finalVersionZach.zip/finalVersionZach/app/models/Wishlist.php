<?php

class Wishlist
{
	public $_PKName = "WishlistId";
	public $listingId;
	public $partListingId;
}