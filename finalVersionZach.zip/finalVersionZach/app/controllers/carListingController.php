<?php

class carListingController extends Controller
{
	public function index()
	{
		$aCarListing = $this->model('CarListing');
		$myCarListings = $aCarListing->get();

		$this->view('CarListing/index',['carlistings'=>$myCarListings]);

/*		$aUsername = $this->model('Login');
		$myUsernames = $aUsername->get();*/
	}

	public function search(){
		$searchTerm = $_GET['search'];
		$aCarListing = $this->model('CarListing');

		if(!isset($_GET["sorting"]) && !isset($_GET["region"]))
		{
			$myCarListings = $aCarListing->where('carModel','LIKE',"%$searchTerm%")->ORwhere('carMake','LIKE',"%$searchTerm%")->ORwhere('carTrim','LIKE',"%$searchTerm%")->
			ORwhere('carYear','LIKE',"%$searchTerm%")->ORwhere('description','LIKE',"%$searchTerm%")->ORwhere('mileage','LIKE',"$searchTerm")->ORwhere('price','LIKE',"$searchTerm")->get();
			$this->view('CarListing/index',['carlistings'=>$myCarListings]);
		}

		//Chronological or Alphabetical Search
		if(isset($_GET['sorting'])){
			$sorting = $_GET['sorting'];

			if($sorting == "Chrono"){
				$myCarListings = $aCarListing->where('carModel','LIKE',"%$searchTerm%")->ORwhere('carMake','LIKE',"%$searchTerm%")->ORwhere('carTrim','LIKE',"%$searchTerm%")->
				ORwhere('carYear','LIKE',"%$searchTerm%")->ORwhere('description','LIKE',"%$searchTerm%")->ORwhere('mileage','LIKE',"$searchTerm")->ORwhere('price','LIKE',"$searchTerm")->get();
				sort($myCarListings);
				$this->view('CarListing/index',['carlistings'=>$myCarListings]);
			}

			else if($sorting == "RChrono"){
				$myCarListings = $aCarListing->where('carModel','LIKE',"%$searchTerm%")->ORwhere('carMake','LIKE',"%$searchTerm%")->ORwhere('carTrim','LIKE',"%$searchTerm%")->
				ORwhere('carYear','LIKE',"%$searchTerm%")->ORwhere('description','LIKE',"%$searchTerm%")->ORwhere('mileage','LIKE',"$searchTerm")->ORwhere('price','LIKE',"$searchTerm")->get();
				rsort($myCarListings);
				$this->view('CarListing/index',['carlistings'=>$myCarListings]);
			}

			else if($sorting == "Alpha"){
				$myCarListings = $aCarListing->where('carModel','LIKE',"%$searchTerm%")->ORwhere('carMake','LIKE',"%$searchTerm%")->ORwhere('carTrim','LIKE',"%$searchTerm%")->
				ORwhere('carYear','LIKE',"%$searchTerm%")->ORwhere('description','LIKE',"%$searchTerm%")->ORwhere('mileage','LIKE',"$searchTerm")->ORwhere('price','LIKE',"$searchTerm")->get();
				sort($myCarListings);
				$this->view('CarListing/index',['carlistings'=>$myCarListings]);
			}
		}

		// Region Search
		if(isset($_GET["region"])){
			$region = $_GET["region"];

			$myCarListings = $aCarListing->where('regionid', 'LIKE', "$region")->get();
			$this->view('CarListing/index',['carlistings'=>$myCarListings]);
		}
	}


	public function create()
	{
		//$user = $_SESSION['userID'];

		if(LoginCore::isLoggedIn()){
			if(isset($_POST['action'])){

				date_default_timezone_set('Canada/Eastern');
				$date = date('Y-m-d', time());

				$newCarListing = $this->model('CarListing');
				$newCarListing->carMake = $_POST['carMake'];
				$newCarListing->carModel = $_POST['carModel'];
				$newCarListing->carTrim = $_POST['carTrim'];
				$newCarListing->carYear = $_POST['carYear'];
				$newCarListing->description = $_POST['description'];
				$newCarListing->mileage = $_POST['mileage'];
				$newCarListing->price = $_POST['price'];
				$newCarListing->postDate = $date;
				$newCarListing->loginId = $_SESSION['userID'];
				$newCarListing->regionId = $_POST['RegionId'];
				$newCarListing->views = '0';

				$newCarListing->insert();
				header('location:/CarListing/index');

			}else{
				$regions = $this->model('Region')->get();
				$this->view('CarListing/create', ['regions'=>$regions]);
			}
		}else{
			echo '<script> language="javascript">';
			echo 'alert("You must be logged in to use this feature")</script>';
			$this->view('login/login');
		}
	}
	
	function delete($carListingId)
	{
		if(LoginCore::isLoggedIn()){
			$model = $this->model('carListing');
			$listing = $model->where('loginId', '=', "$carListingId")->get()[0];
			$id = $listing->loginId;
			$aCarListing = $this->model('CarListing');
			$aCarListing->CarListingId = $carListingId;
			$aCarListing->delete();
			header("location:/CarListing/index");
		}else{
			echo '<script> language="javascript">';
			echo 'alert("You must be logged in to use this feature")</script>';
			$this->view('login/login');
		}
	}

	function details($carListingId)
	{
		$user = $_SESSION['userID'];
		$carListing = $this->model('CarListing')->where("CarListingId",'=',$carListingId)->get()[0];
		$comments = $this->model('Comment')->where("ListingId",'=', $carListingId)->get();
		$viewCount = $carListing->Views;
		$viewCount++;
		$carListing->Views = $viewCount;

		$carListing->update();

		$this->view('CarListing/details',['carListingId'=>$carListingId, 'carListing'=>$carListing, 'comments'=>$comments]);
	}

	public function addComment($carListingId)
	{
		if(LoginCore::isLoggedIn()){
			if(isset($_POST['action'])){
				$newComment = $this->model('Comment');
				$newComment->Comment = $_POST['comment'];
				$newComment->LoginId = $_SESSION['userID'];
				$newComment->ListingId = $carListingId;

				$newComment->insert();

				$this->details($carListingId);
			}
		}else{
			echo '<script> language="javascript">';
			echo 'alert("You must be logged in to use this feature")</script>';
			$this->view('login/login');
		}
	}

	public function deleteComment($commentId, $carListingId)
	{
		if(LoginCore::isLoggedIn()){
			$aComment = $this->model('Comment');
			$aComment->CommentId = $commentId;
			$aComment->delete();
			$this->details($carListingId);
		}else{
			echo '<script> language="javascript">';
			echo 'alert("You must be logged in to use this feature")</script>';
			$this->view('login/login');
		}
	}

	public function editComment($commentId, $carListingId)
	{

		if(isset($_POST['action']))
		{
			$comment = $this->model('Comment');
			$session = $comment->where("CommentId", '=', $commentId)->get()[0];
			$session->CommentId = $commentId;
			$session->Comment = $_POST['comment'];
			$session->update();

			$this->details($carListingId);
		}
	}

	public function redirectEditComment($commentId)
	{
		if(LoginCore::isLoggedIn()){
			$user = $_SESSION['userID'];
			$comment = $this->model('Comment')->where("CommentId", '=', $commentId)->get()[0];
			$this->view('CarListing/editComment',['commentId'=>$commentId, 'comment'=>$comment]);
		}else{
			echo '<script> language="javascript">';
			echo 'alert("You must be logged in to use this feature")</script>';
			$this->view('login/login');
		}
	}

	public function edit($carListingId)
	{
		if(isset($_POST['action']))
		{
			$listing = $this->model('CarListing');
			$session = $listing->where("CarListingId",'=', $carListingId)->get()[0];
			$session->CarListingId = $carListingId;
			$session->CarMake = $_POST['carMake'];
			$session->CarModel = $_POST['carModel'];
			$session->CarTrim = $_POST['carTrim'];
			$session->CarYear = $_POST['carYear'];
			$session->Description = $_POST['description'];
			$session->Mileage = $_POST['mileage'];
			$session->Price = $_POST['price'];

			$session->update();

			header('location:/carListing/index');
		}
	}

	public function redirectEdit($carListingId)
	{
		if(LoginCore::isLoggedIn()){
			$user = $_SESSION['userID'];
			$carListing = $this->model('CarListing')->where("CarListingId",'=',$carListingId)->get()[0];
			$this->view('CarListing/edit',['carListingId'=>$carListingId, 'carListing'=>$carListing]);
		}else{
			echo '<script> language="javascript">';
			echo 'alert("You must be logged in to use this feature")</script>';
			$this->view('login/login');
		}
	}
}
