<?php

class Comment extends Model
{
	public $_PKName = "CommentId";
	public $LoginId;
	public $Comment;
	public $ListingId;
}