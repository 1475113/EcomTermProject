<?php

class InboxController extends Controller
{
	public function index()
	{
		$aInbox = $this->model('Inbox');
		$inbox = $aInbox->get();
		/*foreach ($inbox as $item) {
			$item = $inbox->find();
		}*/

		$this->view('Inbox/index',['inbox'=>$inbox]);

/*		$aUsername = $this->model('Login');
		$myUsernames = $aUsername->get();*/
	}

	public function create()
	{
		//$user = $_SESSION['userID'];

		date_default_timezone_set("America/New_York");
		$date = date('Y-m-d');

		if(isset($_POST['action'])){
		try{
			$newInbox = $this->model('Inbox');
			$newInbox->SenderLoginId = $_SESSION['userID'];
			$newInbox->ReceiverLoginId = $_POST['ReceiverLoginId'];
			$newInbox->Message = $_POST['Message'];
			$newInbox->Date = $date;
			$newInbox->insert();
			header('location:/Inbox/index');
		}catch(Exception $e){
			echo $e->getMessage();
			header('location:/Inbox/create');
		}

		}else{
			$this->view('Inbox/create');
		}
	}
}