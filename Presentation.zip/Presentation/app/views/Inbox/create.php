<html>
<head>
	<title>Send a message</title>
	<link rel="stylesheet" type="text/css" href="/assets/css/bootstrapz.css" />
	<script src="/js/boostrap.js"></script>
</head>
<body>
	 <div class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">
                <!--<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>-->
                <a class="navbar-brand" href="#">CarTrader</a>
            </div>
            <div class="navbar-collapse collapse">
                <ul class="nav navbar-nav ">
                        <li><a href="/login/logout">Log Out</a></li>
                        <li><a href="/carListing/index">Car Listings</a></li>
                        <li><a href="/carPartListing/index">Car Part Listings</a></li>
                        <li><a href="/CarListing/wishlistindex"> Wishlist</a></li>
                        <li><a href="/Inbox/index"> Inbox </a></li>
                    <!--<a href="#" class="btn btn-primary">Search</a>-->
                </ul>
            </div>
        </div>
    </div>
	<div class="container">
		<h1>Send a message</h1>
		<form method="post" action="/Inbox/create" class="form-horizontal" enctype="multipart/form-data">
			<div class="form-group">
			<label for="ReceiverLoginId">Receiver</label>
			<input type="text" class="form-control" name="ReceiverLoginId" id="ReceiverLoginId" />
			</div>
			<div class="form-group">
			<label for="Message">Message</label>
			<input type="text" class="form-control" name="Message" id="Message" />
			</div>
			<div class="form-group">
			<input type="submit" class="btn btn-default" name="action" value="Publish Car Listing" />
			</div>
		</form>
	</div>
</body>