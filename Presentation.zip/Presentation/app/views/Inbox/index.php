<html>
<head>
	<title>Inbox</title>
	<link rel="stylesheet" type="text/css" href="/assets/css/bootstrapz.css" />
	<script src="/js/boostrap.js"></script>
</head>
<body>
	 <div class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">
                <!--<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>-->
                <a class="navbar-brand" href="/home/index/">CarTrader</a>
            </div>
            <div class="navbar-collapse collapse">
                <ul class="nav navbar-nav ">
                        <li><a href="/login/logout">Log Out</a></li>
                        <li><a href="/carListing/index">Car Listings</a></li>
                        <li><a href="/carPartListing/index">Car Part Listings</a></li>
                        <li><a href="/CarListing/wishlistindex"> Wishlist</a></li>
                        <li><a href="/Inbox/index"> Inbox </a></li>
                    <!--<a href="#" class="btn btn-primary">Search</a>-->
                </ul>
            </div>
        </div>
    </div>
	<div class="container">
		<h1>Messages</h1>
			<form action="/Inbox/create">
				<input type="submit" name="action" value='Send a Message'/>
			</form>
		</form><br>
		<br>

		<table class="table table-striped">
			<tr>
				<th>Sender</th>
				<th>Receiver</th>
				<th>Message</th>
				<th>Date</th>
			</tr>
			<?php
			foreach ($data['inbox'] as $message) {

				$username = $_SESSION['username'];

				if($_SESSION['userID'] == $message->ReceiverLoginId){
				echo "<tr><td>$message->SenderLoginId</td>";
				echo "<td>$username</td>";
				echo "<td>$message->Message</td>";
				echo "<td>$message->Date</td>";
			}
			}
				?>
		</table>
</body>
</html>