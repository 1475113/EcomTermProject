<html>
<head>
	<title> Wishlist </title>
	<link rel="stylesheet" type="text/css" href="/assets/css/bootstrapz.css" />
	<script src="/js/boostrap.js"></script>
</head>
<body>
	 <div class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">
                <!--<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>-->
                <a class="navbar-brand" href="/home/index/">CarTrader</a>
            </div>
            <div class="navbar-collapse collapse">
                <ul class="nav navbar-nav ">
                        <li><a href="/login/logout">Log Out</a></li>
                        <li><a href="/carListing/index">Car Listings</a></li>
                        <li><a href="/carPartListing/index">Car Part Listings</a></li>
                        <li><a href="/CarListing/wishlistindex"> Wishlist</a></li>
                        <li><a href="/Inbox/index"> Inbox </a></li>
                    <!--<a href="#" class="btn btn-primary">Search</a>-->
                </ul>
            </div>
        </div>
    </div>
	<div class="container">
		<h1>Wishlist</h1>
		<table class="table table-striped">
			<tr>
				<th>Car Make</th>
				<th>Car Model</th>
				<th>Car Trim</th>
				<th>Car Year</th>
			</tr>
			<?php
			foreach ($data['wishlist'] as $carlisting) {
				if($_SESSION['userID'] == $carlisting->LoginId){
				echo "<tr><td>$carlisting->CarMake</td>";
				echo "<td>$carlisting->CarModel</td>";
				echo "<td>$carlisting->CarTrim</td>";
				echo "<td>$carlisting->CarYear</td>";
				echo "<td><a class='btn btn-default' href='/carListing/deleteWishlist/$carlisting->WishlistId'>Delete</a></td></tr>";
				//echo "$carlisting->WishlistId";
				}
			}
			?>
		</table>
</body>
</html>