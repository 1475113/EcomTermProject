<html>
<head>
	<title>Car Listings</title>
	<link rel="stylesheet" type="text/css" href="/assets/css/bootstrapz.css" />
	<script src="/js/boostrap.js"></script>
</head>
<body>
	<div class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">
				<div class="navbar-collapse collapse">
			                <ul class="nav navbar-nav ">
			                    <li><a href="/login/logout">Log Out</a></li>
			                    <li><a href="/carListing/index">Car Listings</a></li>
			                    <li><a href="/carPartListing/index">Car Part Listings</a></li>
			                    <!--<a href="#" class="btn btn-primary">Search</a>-->
			                </ul>
			    </div>
			</div>
		</div>
	</div>
	<div class="container">
		<h1>Car Listings</h1>
		<form method="get" action="/CarListing/search" class="form-inline">
			<div class="form-group">
				<label for="q">Search by Keyword</label>
				<input type="text" class="form-control" name="search" id="search"/>
			</div>
			<label>&nbsp;&nbsp;&nbsp;&nbsp;</label>
			<div class="form-group">
				<select name="sorting">
					<option value="" disabled selected>Select Sorting Type...</option>
					<option value="Chrono">Chronological</option>
					<option value="RChrono">Reverse Chronological</option>>
				</select>
				<label>&nbsp;&nbsp;&nbsp;&nbsp;</label>
				<select name="region">
					<option value="" disabled selected>Select Region...</option>
					<option value="1">Montreal</option>
					<option value="2">Laval</option>
					<option value="3">Laurentides</option>
					<option value="4">Monteregie</option>
					<option value="5">Lanaudiere</option>
				</select>
			</div>
			<label>&nbsp;&nbsp;&nbsp;&nbsp;</label>
			<div class="form-group">
				<input type="submit" class="btn btn-default" name="action" value='Search'/>
			</div>
		</form>

		<div class="form-group">
			<form action="/CarListing/create">
				<input type="submit" name="action" value='Create'/>
			</form>
		</div>

		<br>
		<br>

		<table class="table table-striped">
			<tr>
				<th>		</th>
				<th>Car Make</th>
				<th>Car Model</th>
				<th>Car Trim</th>
				<th>Car Year</th>
				<th>Post Date</th>
				<th>Description</th>
				<th>Seller Username</th>
				<th>Mileage</th>
				<th>Price</th>
				<th>Region</th>
				<th>Image</th>
				<th>		</th>
				<th>		</th>
			</tr>
			<?php
			foreach ($data['carlistings'] as $carlisting) {
				$model = $this->model('Login');
				$login = $model->where('LoginId','=', "$carlisting->LoginId")->get()[0];
				$username = $login->Username;

				$regionModel = $this->model('Region');
				$region = $regionModel->where('RegionId', '=', "$carlisting->RegionId")->get()[0];
				$regionName = $region->RegionName;

				echo "<tr><td><a class='btn btn-default' href='/carListing/details/$carlisting->CarListingId'>Details</a></td>";
				echo "<td>$carlisting->CarMake</td>";
				echo "<td>$carlisting->CarModel</td>";
				echo "<td>$carlisting->CarTrim</td>";
				echo "<td>$carlisting->CarYear</td>";
				echo "<td>$carlisting->PostDate</td>";
				echo "<td>$carlisting->Description</td>";
				echo "<td>$username</td>";
				echo "<td>$carlisting->Mileage km</td>";
				echo "<td>$$carlisting->Price</td>";
				echo "<td>$regionName</td>";
				echo "<td>$carlisting->ImageId</td>";

				if($_SESSION['userID'] == $carlisting->LoginId || $_SESSION['userStatus'] == 4)
				{
					echo "<td><a class='btn btn-default' href='/carListing/delete/$carlisting->CarListingId'>Delete</a></td>";
					echo "<td><a class='btn btn-default' href='/carListing/redirectEdit/$carlisting->CarListingId'>Edit</a></td></tr>";
				}else{
					echo "<td></td>";
					echo "<td></td></tr>";
				}
			}
			?>
		</table>
</body>
</html>