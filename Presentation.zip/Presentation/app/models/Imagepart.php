<?php

class Imagepart extends Model
{
	public $_PKName = "ImageId";
	public $ListingId;
	public $ImageURL;
}