<html>
<head>
	<title>Car Listings</title>
	<link rel="stylesheet" type="text/css" href="/assets/css/bootstrap.css" />
	<script src="/js/boostrap.js"></script>
</head>
<body>
	<div class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">
				<div class="navbar-collapse collapse">
			                <ul class="nav navbar-nav ">
			                	<li><a href="/profile/redirectToProfile">Home</a></li>
			                    <li><a href="/login/logout">Log Out</a></li>
			                    <li><a href="/carListing/index">Car Listings</a></li>
					    <li><a href="/carPartListing/index">Car Part Listings</a></li>
			                    <!--<a href="#" class="btn btn-primary">Search</a>-->
			                </ul>
			    </div>
			</div>
		</div>
	</div>

	<div class="container">
		<h1>Car Part Listings - Details</h1>
		<form method="post" action="/carPartListing/edit/<?php echo $data['carPartListingId']; ?>" class="form-horizontal">
			<?php
			$model = $this->model('Login');
			$loginId = $data['carPartListing']->LoginId;
			$listCreator = $model->where('LoginId','=', "$loginId")->get()[0];
			$username = $listCreator->Username;


			$model = $this->model('Region');
			$id = $data['carPartListing']->RegionId;
			$listingRegion = $model->where('RegionId','=',"$id")->get()[0];
			$region = $listingRegion->RegionName;
			?>
			<div class="form-group">
			<label>Seller Username</label>
			<input type="text" class="form-control" name="loginId" id="loginId" readonly="readonly" value="<?php echo $username; ?>" />
			</div>
			<div class="form-group">
			<label>Region</label>
			<input type="text" class="form-control" name="regionId" id="regionId" readonly="readonly" value="<?php echo $region; ?>" />
			</div>
			<div class="form-group">
			<label>Description</label>
			<input type="text" class="form-control" name="description" id="description" readonly="readonly" value="<?php echo $data['carPartListing']->Description; ?>"/>
			</div>
			<div class="form-group">
			<label>Price</label>
			<input type="text" class="form-control" name="price" id="price" readonly="readonly" value="<?php echo $data['carPartListing']->Price; ?>"/>
			</div>
			<div class="form-group">
			<label>Post Date</label>
			<input type="text" class="form-control" name="price" id="price" readonly="readonly" value="<?php echo $data['carPartListing']->PostDate; ?>"/>
			</div>
			<div class="form-group">
			<br/>
		</form>
			<?php
				$id = $data['carPartListing']->LoginId;

				echo "<a class ='btn btn-success' href='/profile/extProfile/$id'>Visit Creator</a>";		
			?>
	</div>
</body>
