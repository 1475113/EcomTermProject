<?php

class CarPartListing extends Model
{
	public $_PKName = "CarPartListingId";
	public $PostDate;
	public $Description;
	public $LoginId;
	public $Price;
	public $ImageId;
	public $RegionId;
	public $Views;
}